package com.yahoo.financial.api.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import yahoofinance.Stock;
import yahoofinance.YahooFinance;

import javax.inject.Singleton;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Map;

@Singleton
public class ProviderService {

    protected static final Logger LOGGER = LoggerFactory.getLogger(ProviderService.class.getName());

    public Object getProviderStockIndex(String stockIndex) {

        Stock stock = null;
        BigDecimal stockPrice = BigDecimal.ONE;
        try {
            stock = YahooFinance.get(stockIndex);
            stockPrice = stock.getQuote(true).getPrice();
            LOGGER.info("---- STOCK PRICE :: " + stockPrice + " ----");
        } catch (IOException e) {
            LOGGER.error(e.getMessage());
        }
        return stockPrice;
    }
    public Object getListOfStockIndexes(){

        Map<String,Stock> listOfStocks= null;
        try{
            String [] stockSymbols = new String[]{"GOOGL","DJI","IXIC","ETH-USD","BTC-USD","BNB-USD","ADA-USD","BSEN","GSPC","TSLA"};
            listOfStocks=YahooFinance.get(stockSymbols);
            LOGGER.info("---- LIST OF STOCK PRICES :: " + listOfStocks.toString() + " ----");
        }catch (IOException e){
            LOGGER.error(e.getMessage());
        }

        return listOfStocks.toString();
    }
}
