package com.yahoo.financial.api.controller;


import com.yahoo.financial.api.service.ProviderService;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.annotation.QueryValue;
import io.micronaut.security.annotation.Secured;
import io.micronaut.security.rules.SecurityRule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;

@Secured(SecurityRule.IS_AUTHENTICATED)
@Controller("/stocks")
public class ProviderController {

    private static final Logger LOGGER= LoggerFactory.getLogger(ProviderController.class.getName());

    @Inject
    private ProviderService providerService;

    @Get("/single")
    @Produces(MediaType.APPLICATION_JSON)
    public Object getSingleStockPrice(@QueryValue("provider") String stockPriceProvider,
                                      @QueryValue("sindex") String stockIndex){

        if(stockPriceProvider.equals("yahoo")){
            LOGGER.info("---- STOCK PRICE PROVIDER:: "+stockPriceProvider+" ----");
            return providerService.getProviderStockIndex(stockIndex);
        }else {
           LOGGER.info("---- STOCK PRICE PROVIDER ::" + stockPriceProvider + " ----");
            return HttpResponse.badRequest("Invalid Provider hint:: ..provider=yahoo..");
        }
    }

    @Get("/list")
    @Produces(MediaType.APPLICATION_JSON)
    public Object getListOfIndexes(@QueryValue("provider") String stockPriceProvider){
        if(stockPriceProvider.equals("yahoo")){
            LOGGER.info("---- STOCK PRICE PROVIDER:: "+stockPriceProvider+" ----");
            return providerService.getListOfStockIndexes();
        }else {
            LOGGER.info("---- STOCK PRICE PROVIDER ::" + stockPriceProvider + " ----");
            return HttpResponse.badRequest("Invalid Provider hint:: ..provider=yahoo..");
        }
    }
}
